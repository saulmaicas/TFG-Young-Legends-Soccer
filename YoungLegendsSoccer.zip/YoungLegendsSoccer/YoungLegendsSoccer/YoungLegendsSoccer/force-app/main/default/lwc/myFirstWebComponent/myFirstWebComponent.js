import { LightningElement, track } from 'lwc';
export default class MyFirstWebComponent extends LightningElement {
    @track
    contacts = [
        {
            Id: 1,
            Name: 'Young Legends Soccer',
            Title: 'Escuela',
        },
        {
            Id: 2,
            Name: 'Florentino Pérez',
            Title: 'Presidente',
        },
        {
            Id: 3,
            Name: 'Mateu Alemany',
            Title: 'Director Deportivo',
        }
    ];
}